import { motion } from 'motion/react';

export type MoodType = 'happy' | 'energized' | 'calm' | 'comfort' | 'adventurous' | 'light';

interface MoodOption {
  id: MoodType;
  emoji: string;
  label: string;
  color: string;
}

const moods: MoodOption[] = [
  { id: 'happy', emoji: '😊', label: 'Happy', color: '#FFD93D' },
  { id: 'energized', emoji: '⚡', label: 'Energized', color: '#FF6B35' },
  { id: 'calm', emoji: '😌', label: 'Calm', color: '#6BCF7F' },
  { id: 'comfort', emoji: '🤗', label: 'Comfort', color: '#A594F9' },
  { id: 'adventurous', emoji: '🚀', label: 'Adventurous', color: '#FF6B9D' },
  { id: 'light', emoji: '🌟', label: 'Light', color: '#4ECDC4' },
];

interface MoodSelectorProps {
  selectedMood: MoodType | null;
  onSelect: (mood: MoodType) => void;
}

export function MoodSelector({ selectedMood, onSelect }: MoodSelectorProps) {
  return (
    <div className="space-y-4">
      <div className="text-center">
        <h3 className="text-2xl mb-2">How are you feeling today?</h3>
        <p className="text-gray-600">Select your mood to get personalized meal suggestions</p>
      </div>
      
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
        {moods.map((mood) => (
          <motion.button
            key={mood.id}
            onClick={() => onSelect(mood.id)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`relative p-6 rounded-3xl border-2 transition-all ${
              selectedMood === mood.id
                ? 'border-gray-900 shadow-xl'
                : 'border-transparent shadow-md hover:shadow-lg'
            }`}
            style={{
              background: selectedMood === mood.id 
                ? `linear-gradient(135deg, ${mood.color}dd, ${mood.color})`
                : `linear-gradient(135deg, ${mood.color}33, ${mood.color}22)`
            }}
          >
            <div className="flex flex-col items-center gap-2">
              <span className="text-4xl">{mood.emoji}</span>
              <span className={`text-sm ${selectedMood === mood.id ? 'text-gray-900' : 'text-gray-700'}`}>
                {mood.label}
              </span>
            </div>
            
            {selectedMood === mood.id && (
              <motion.div
                layoutId="mood-indicator"
                className="absolute inset-0 rounded-3xl border-4 border-gray-900"
                initial={false}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
              />
            )}
          </motion.button>
        ))}
      </div>
    </div>
  );
}

import { Cloud, CloudRain, Sun, Wind, Snowflake } from 'lucide-react';

export type WeatherType = 'sunny' | 'cloudy' | 'rainy' | 'snowy' | 'windy';

interface WeatherDisplayProps {
  weather: WeatherType;
  temperature: number;
}

const weatherIcons: Record<WeatherType, React.ReactNode> = {
  sunny: <Sun className="w-8 h-8 text-yellow-500" />,
  cloudy: <Cloud className="w-8 h-8 text-gray-400" />,
  rainy: <CloudRain className="w-8 h-8 text-blue-500" />,
  snowy: <Snowflake className="w-8 h-8 text-blue-300" />,
  windy: <Wind className="w-8 h-8 text-gray-500" />,
};

const weatherGradients: Record<WeatherType, string> = {
  sunny: 'from-yellow-400/20 to-orange-400/20',
  cloudy: 'from-gray-300/20 to-gray-400/20',
  rainy: 'from-blue-400/20 to-blue-500/20',
  snowy: 'from-blue-200/20 to-blue-300/20',
  windy: 'from-gray-300/20 to-gray-400/20',
};

export function WeatherDisplay({ weather, temperature }: WeatherDisplayProps) {
  return (
    <div className={`inline-flex items-center gap-3 px-6 py-3 rounded-2xl bg-gradient-to-r ${weatherGradients[weather]} border border-gray-200 backdrop-blur-sm`}>
      {weatherIcons[weather]}
      <div>
        <div className="text-sm text-gray-600">Current Weather</div>
        <div className="flex items-center gap-2">
          <span className="text-2xl">{temperature}°F</span>
          <span className="text-sm text-gray-600 capitalize">{weather}</span>
        </div>
      </div>
    </div>
  );
}

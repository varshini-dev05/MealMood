import { motion } from 'motion/react';
import { Leaf, Wheat, Fish, Flame } from 'lucide-react';

export type DietType = 'vegan' | 'vegetarian' | 'keto' | 'gluten-free' | 'pescatarian' | 'none';

interface DietOption {
  id: DietType;
  icon: React.ReactNode;
  label: string;
  color: string;
}

const dietOptions: DietOption[] = [
  { id: 'vegan', icon: <Leaf className="w-6 h-6" />, label: 'Vegan', color: '#6BCF7F' },
  { id: 'vegetarian', icon: <Leaf className="w-6 h-6" />, label: 'Vegetarian', color: '#4ECDC4' },
  { id: 'keto', icon: <Flame className="w-6 h-6" />, label: 'Keto', color: '#FF6B35' },
  { id: 'gluten-free', icon: <Wheat className="w-6 h-6" />, label: 'Gluten-Free', color: '#FFD93D' },
  { id: 'pescatarian', icon: <Fish className="w-6 h-6" />, label: 'Pescatarian', color: '#A594F9' },
  { id: 'none', icon: <span className="text-2xl">🍽️</span>, label: 'No Restrictions', color: '#FF6B9D' },
];

interface DietaryPreferencesProps {
  selectedDiet: DietType[];
  onToggle: (diet: DietType) => void;
}

export function DietaryPreferences({ selectedDiet, onToggle }: DietaryPreferencesProps) {
  return (
    <div className="space-y-4">
      <div className="text-center">
        <h3 className="text-2xl mb-2">Dietary Preferences</h3>
        <p className="text-gray-600">Select all that apply to you</p>
      </div>
      
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
        {dietOptions.map((option) => {
          const isSelected = selectedDiet.includes(option.id);
          
          return (
            <motion.button
              key={option.id}
              onClick={() => onToggle(option.id)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`p-4 rounded-2xl border-2 transition-all ${
                isSelected
                  ? 'border-gray-900 shadow-xl'
                  : 'border-gray-200 shadow-sm hover:shadow-md'
              }`}
              style={{
                background: isSelected 
                  ? `linear-gradient(135deg, ${option.color}dd, ${option.color})`
                  : 'white'
              }}
            >
              <div className="flex flex-col items-center gap-2">
                <div className={isSelected ? 'text-white' : 'text-gray-700'}>
                  {option.icon}
                </div>
                <span className={`text-xs text-center ${isSelected ? 'text-white' : 'text-gray-700'}`}>
                  {option.label}
                </span>
              </div>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}

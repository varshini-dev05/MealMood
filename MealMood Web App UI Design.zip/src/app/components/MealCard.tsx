import { motion } from 'motion/react';
import { Heart, Clock, Flame, ExternalLink } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export interface Meal {
  id: string;
  name: string;
  description: string;
  image: string;
  calories: number;
  prepTime: number;
  dietType: string[];
  moodAlignment: string;
  recipeUrl?: string;
}

interface MealCardProps {
  meal: Meal;
  isFavorite?: boolean;
  onToggleFavorite: (mealId: string) => void;
  onMarkTried?: (mealId: string) => void;
}

export function MealCard({ meal, isFavorite = false, onToggleFavorite, onMarkTried }: MealCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -8 }}
      className="bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all border border-gray-100"
    >
      {/* Image */}
      <div className="relative h-56 overflow-hidden bg-gradient-to-br from-gray-100 to-gray-200">
        <ImageWithFallback
          src={meal.image}
          alt={meal.name}
          className="w-full h-full object-cover"
        />
        
        {/* Favorite Button */}
        <button
          onClick={() => onToggleFavorite(meal.id)}
          className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center hover:scale-110 transition-transform shadow-lg"
        >
          <Heart
            className={`w-5 h-5 ${isFavorite ? 'fill-red-500 text-red-500' : 'text-gray-600'}`}
          />
        </button>
        
        {/* Mood Badge */}
        <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-white/90 backdrop-blur-sm text-sm">
          {meal.moodAlignment}
        </div>
      </div>
      
      {/* Content */}
      <div className="p-6 space-y-4">
        <div>
          <h3 className="text-xl mb-2">{meal.name}</h3>
          <p className="text-gray-600 text-sm line-clamp-2">{meal.description}</p>
        </div>
        
        {/* Tags */}
        <div className="flex flex-wrap gap-2">
          {meal.dietType.map((diet) => (
            <span
              key={diet}
              className="px-3 py-1 text-xs rounded-full bg-gradient-to-r from-[#6BCF7F]/20 to-[#4ECDC4]/20 text-gray-700 border border-[#6BCF7F]/30"
            >
              {diet}
            </span>
          ))}
        </div>
        
        {/* Stats */}
        <div className="flex items-center gap-4 text-sm text-gray-600">
          <div className="flex items-center gap-1">
            <Flame className="w-4 h-4 text-[#FF6B35]" />
            <span>{meal.calories} cal</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4 text-[#A594F9]" />
            <span>{meal.prepTime} min</span>
          </div>
        </div>
        
        {/* Actions */}
        <div className="flex gap-2 pt-2">
          {meal.recipeUrl && (
            <a
              href={meal.recipeUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-[#FF6B35] to-[#FF6B9D] text-white hover:shadow-lg transition-shadow"
            >
              <span>View Recipe</span>
              <ExternalLink className="w-4 h-4" />
            </a>
          )}
          
          {onMarkTried && (
            <button
              onClick={() => onMarkTried(meal.id)}
              className="px-4 py-2 rounded-full border-2 border-gray-200 text-gray-700 hover:border-[#6BCF7F] hover:bg-[#6BCF7F]/10 transition-all"
            >
              Mark as Tried
            </button>
          )}
        </div>
      </div>
    </motion.div>
  );
}

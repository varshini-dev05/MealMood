import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Heart, Clock } from 'lucide-react';
import { MealCard, Meal } from '../components/MealCard';

// Mock meal data (same as MealSuggestions)
const mockMeals: Meal[] = [
  {
    id: '1',
    name: 'Rainbow Buddha Bowl',
    description: 'A vibrant and nutritious bowl packed with colorful veggies, quinoa, and tahini dressing',
    image: 'https://images.unsplash.com/photo-1734988149239-85943a98833c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMGhlYWx0aHklMjBtZWFsJTIwYm93bHxlbnwxfHx8fDE3NzAyNzE1Njh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    calories: 450,
    prepTime: 25,
    dietType: ['Vegan', 'Gluten-Free'],
    moodAlignment: '😊 Happy',
    recipeUrl: '#',
  },
  {
    id: '2',
    name: 'Fluffy Blueberry Pancakes',
    description: 'Light and airy pancakes topped with fresh blueberries and maple syrup',
    image: 'https://images.unsplash.com/photo-1584278858764-2ddcd7f228da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGJyZWFrZmFzdCUyMHBhbmNha2VzfGVufDF8fHx8MTc3MDI3MTU2OXww&ixlib=rb-4.1.0&q=80&w=1080',
    calories: 380,
    prepTime: 20,
    dietType: ['Vegetarian'],
    moodAlignment: '🤗 Comfort',
    recipeUrl: '#',
  },
  {
    id: '3',
    name: 'Creamy Pesto Pasta',
    description: 'Delicious pasta tossed in homemade basil pesto with cherry tomatoes',
    image: 'https://images.unsplash.com/photo-1723588636244-e82f63cb01e3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZWdldGFyaWFuJTIwcGFzdGElMjBkaXNofGVufDF8fHx8MTc3MDE4MDQ5OXww&ixlib=rb-4.1.0&q=80&w=1080',
    calories: 520,
    prepTime: 30,
    dietType: ['Vegetarian'],
    moodAlignment: '😌 Calm',
    recipeUrl: '#',
  },
  {
    id: '4',
    name: 'Mediterranean Salad',
    description: 'Fresh and crisp salad with feta cheese, olives, and lemon vinaigrette',
    image: 'https://images.unsplash.com/photo-1578679664605-80268ff31300?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGh5JTIwc2FsYWQlMjBsdW5jaHxlbnwxfHx8fDE3NzAyNDk3MzN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    calories: 320,
    prepTime: 15,
    dietType: ['Vegetarian', 'Gluten-Free'],
    moodAlignment: '🌟 Light',
    recipeUrl: '#',
  },
  {
    id: '5',
    name: 'Grilled Herb Chicken',
    description: 'Juicy grilled chicken breast with roasted vegetables and herbs',
    image: 'https://images.unsplash.com/photo-1496074620649-6b1b02e5c1c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmlsbGVkJTIwY2hpY2tlbiUyMGRpbm5lcnxlbnwxfHx8fDE3NzAxODU2MDB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    calories: 420,
    prepTime: 35,
    dietType: ['Keto', 'Gluten-Free'],
    moodAlignment: '⚡ Energized',
    recipeUrl: '#',
  },
  {
    id: '6',
    name: 'Sushi Roll Platter',
    description: 'Assorted fresh sushi rolls with wasabi and pickled ginger',
    image: 'https://images.unsplash.com/photo-1700324822763-956100f79b0d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXNoaSUyMGphcGFuZXNlJTIwZm9vZHxlbnwxfHx8fDE3NzAyNjExMTB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    calories: 380,
    prepTime: 40,
    dietType: ['Pescatarian', 'Gluten-Free'],
    moodAlignment: '🚀 Adventurous',
    recipeUrl: '#',
  },
];

type TabType = 'saved' | 'tried';

export function Favorites() {
  const [activeTab, setActiveTab] = useState<TabType>('saved');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [tried, setTried] = useState<string[]>([]);
  
  useEffect(() => {
    // Load from localStorage
    const savedFavorites = localStorage.getItem('favorites');
    const savedTried = localStorage.getItem('tried');
    
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
    if (savedTried) {
      setTried(JSON.parse(savedTried));
    }
  }, []);
  
  const handleToggleFavorite = (mealId: string) => {
    const newFavorites = favorites.includes(mealId)
      ? favorites.filter(id => id !== mealId)
      : [...favorites, mealId];
    
    setFavorites(newFavorites);
    localStorage.setItem('favorites', JSON.stringify(newFavorites));
  };
  
  const handleMarkTried = (mealId: string) => {
    const newTried = tried.includes(mealId)
      ? tried.filter(id => id !== mealId)
      : [...tried, mealId];
    
    setTried(newTried);
    localStorage.setItem('tried', JSON.stringify(newTried));
  };
  
  const favoriteMeals = mockMeals.filter(meal => favorites.includes(meal.id));
  const triedMeals = mockMeals.filter(meal => tried.includes(meal.id));
  const displayMeals = activeTab === 'saved' ? favoriteMeals : triedMeals;
  
  return (
    <div className="min-h-screen pt-16 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl mb-2">My Favorites & History</h1>
          <p className="text-gray-600">Your saved meals and dishes you've tried</p>
        </div>
        
        {/* Tabs */}
        <div className="flex gap-4 mb-8 border-b border-gray-200">
          <button
            onClick={() => setActiveTab('saved')}
            className={`flex items-center gap-2 px-6 py-3 border-b-2 transition-all ${
              activeTab === 'saved'
                ? 'border-[#FF6B35] text-[#FF6B35]'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <Heart className={`w-5 h-5 ${activeTab === 'saved' ? 'fill-current' : ''}`} />
            <span>Saved ({favorites.length})</span>
          </button>
          
          <button
            onClick={() => setActiveTab('tried')}
            className={`flex items-center gap-2 px-6 py-3 border-b-2 transition-all ${
              activeTab === 'tried'
                ? 'border-[#6BCF7F] text-[#6BCF7F]'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <Clock className="w-5 h-5" />
            <span>Tried ({tried.length})</span>
          </button>
        </div>
        
        {/* Meal Grid */}
        {displayMeals.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {displayMeals.map((meal, index) => (
              <motion.div
                key={meal.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <MealCard
                  meal={meal}
                  isFavorite={favorites.includes(meal.id)}
                  onToggleFavorite={handleToggleFavorite}
                  onMarkTried={handleMarkTried}
                />
              </motion.div>
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <div className="text-6xl mb-4">
              {activeTab === 'saved' ? '💝' : '🍴'}
            </div>
            <h3 className="text-2xl mb-2">
              {activeTab === 'saved' ? 'No saved meals yet' : 'No tried meals yet'}
            </h3>
            <p className="text-gray-600">
              {activeTab === 'saved' 
                ? 'Start exploring meals and save your favorites!' 
                : 'Mark meals as tried to keep track of what you\'ve enjoyed!'}
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
}

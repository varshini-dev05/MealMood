import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { MoodSelector, MoodType } from '../components/MoodSelector';
import { DietaryPreferences, DietType } from '../components/DietaryPreferences';
import { WeatherDisplay, WeatherType } from '../components/WeatherDisplay';

export function LandingPage() {
  const navigate = useNavigate();
  const [selectedMood, setSelectedMood] = useState<MoodType | null>(null);
  const [selectedDiets, setSelectedDiets] = useState<DietType[]>([]);
  const [currentWeather] = useState<WeatherType>('sunny');
  const [temperature] = useState(72);
  
  const handleDietToggle = (diet: DietType) => {
    if (selectedDiets.includes(diet)) {
      setSelectedDiets(selectedDiets.filter(d => d !== diet));
    } else {
      setSelectedDiets([...selectedDiets, diet]);
    }
  };
  
  const handleGetSuggestions = () => {
    if (selectedMood) {
      navigate('/suggestions', { 
        state: { 
          mood: selectedMood, 
          diets: selectedDiets,
          weather: currentWeather,
          temperature 
        } 
      });
    }
  };
  
  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Gradient Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#FFD93D]/20 via-[#FF6B35]/20 to-[#FF6B9D]/20" />
        
        {/* Decorative Circles */}
        <div className="absolute top-20 right-20 w-64 h-64 bg-[#6BCF7F]/20 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-[#A594F9]/20 rounded-full blur-3xl" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <div className="flex items-center justify-center gap-2 mb-4">
              <Sparkles className="w-6 h-6 text-[#FFD93D]" />
              <span className="text-[#FF6B35] text-sm uppercase tracking-wider">Personalized Meal Discovery</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl mb-6 bg-gradient-to-r from-[#FF6B35] via-[#FF6B9D] to-[#A594F9] bg-clip-text text-transparent pb-2">
              What Should I Eat Today?
            </h1>
            
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Discover delicious meals perfectly matched to your mood, dietary preferences, and the weather outside!
            </p>
          </motion.div>
          
          {/* Weather Display */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="flex justify-center mb-16"
          >
            <WeatherDisplay weather={currentWeather} temperature={temperature} />
          </motion.div>
          
          {/* Mood Selection */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mb-16"
          >
            <MoodSelector selectedMood={selectedMood} onSelect={setSelectedMood} />
          </motion.div>
          
          {/* Dietary Preferences */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mb-16"
          >
            <DietaryPreferences selectedDiet={selectedDiets} onToggle={handleDietToggle} />
          </motion.div>
          
          {/* CTA Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="text-center"
          >
            <button
              onClick={handleGetSuggestions}
              disabled={!selectedMood}
              className={`group inline-flex items-center gap-3 px-8 py-4 rounded-full text-lg transition-all ${
                selectedMood
                  ? 'bg-gradient-to-r from-[#FF6B35] to-[#FF6B9D] text-white hover:shadow-2xl hover:scale-105 cursor-pointer'
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              }`}
            >
              <span>Get Meal Suggestions</span>
              <ArrowRight className={`w-5 h-5 ${selectedMood ? 'group-hover:translate-x-1' : ''} transition-transform`} />
            </button>
            
            {!selectedMood && (
              <p className="mt-4 text-sm text-gray-500">Please select your mood to continue</p>
            )}
          </motion.div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8 rounded-3xl bg-gradient-to-br from-[#FFD93D]/10 to-[#FF6B35]/10 border border-[#FFD93D]/30">
              <div className="text-4xl mb-4">🎯</div>
              <h3 className="text-xl mb-2">Mood-Based</h3>
              <p className="text-gray-600">Get meal recommendations that match how you're feeling right now</p>
            </div>
            
            <div className="text-center p-8 rounded-3xl bg-gradient-to-br from-[#6BCF7F]/10 to-[#4ECDC4]/10 border border-[#6BCF7F]/30">
              <div className="text-4xl mb-4">🥗</div>
              <h3 className="text-xl mb-2">Diet-Friendly</h3>
              <p className="text-gray-600">Respect your dietary preferences with personalized options</p>
            </div>
            
            <div className="text-center p-8 rounded-3xl bg-gradient-to-br from-[#A594F9]/10 to-[#FF6B9D]/10 border border-[#A594F9]/30">
              <div className="text-4xl mb-4">🌤️</div>
              <h3 className="text-xl mb-2">Weather-Aware</h3>
              <p className="text-gray-600">Suggestions adapt to the current weather conditions</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

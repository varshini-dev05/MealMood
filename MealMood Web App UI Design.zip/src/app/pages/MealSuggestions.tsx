import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { RefreshCw, ArrowLeft } from 'lucide-react';
import { MealCard, Meal } from '../components/MealCard';

// Mock meal data
const mockMeals: Meal[] = [
  {
    id: '1',
    name: 'Rainbow Buddha Bowl',
    description: 'A vibrant and nutritious bowl packed with colorful veggies, quinoa, and tahini dressing',
    image: 'https://images.unsplash.com/photo-1734988149239-85943a98833c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMGhlYWx0aHklMjBtZWFsJTIwYm93bHxlbnwxfHx8fDE3NzAyNzE1Njh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    calories: 450,
    prepTime: 25,
    dietType: ['Vegan', 'Gluten-Free'],
    moodAlignment: '😊 Happy',
    recipeUrl: '#',
  },
  {
    id: '2',
    name: 'Fluffy Blueberry Pancakes',
    description: 'Light and airy pancakes topped with fresh blueberries and maple syrup',
    image: 'https://images.unsplash.com/photo-1584278858764-2ddcd7f228da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGJyZWFrZmFzdCUyMHBhbmNha2VzfGVufDF8fHx8MTc3MDI3MTU2OXww&ixlib=rb-4.1.0&q=80&w=1080',
    calories: 380,
    prepTime: 20,
    dietType: ['Vegetarian'],
    moodAlignment: '🤗 Comfort',
    recipeUrl: '#',
  },
  {
    id: '3',
    name: 'Creamy Pesto Pasta',
    description: 'Delicious pasta tossed in homemade basil pesto with cherry tomatoes',
    image: 'https://images.unsplash.com/photo-1723588636244-e82f63cb01e3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZWdldGFyaWFuJTIwcGFzdGElMjBkaXNofGVufDF8fHx8MTc3MDE4MDQ5OXww&ixlib=rb-4.1.0&q=80&w=1080',
    calories: 520,
    prepTime: 30,
    dietType: ['Vegetarian'],
    moodAlignment: '😌 Calm',
    recipeUrl: '#',
  },
  {
    id: '4',
    name: 'Mediterranean Salad',
    description: 'Fresh and crisp salad with feta cheese, olives, and lemon vinaigrette',
    image: 'https://images.unsplash.com/photo-1578679664605-80268ff31300?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGh5JTIwc2FsYWQlMjBsdW5jaHxlbnwxfHx8fDE3NzAyNDk3MzN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    calories: 320,
    prepTime: 15,
    dietType: ['Vegetarian', 'Gluten-Free'],
    moodAlignment: '🌟 Light',
    recipeUrl: '#',
  },
  {
    id: '5',
    name: 'Grilled Herb Chicken',
    description: 'Juicy grilled chicken breast with roasted vegetables and herbs',
    image: 'https://images.unsplash.com/photo-1496074620649-6b1b02e5c1c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmlsbGVkJTIwY2hpY2tlbiUyMGRpbm5lcnxlbnwxfHx8fDE3NzAxODU2MDB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    calories: 420,
    prepTime: 35,
    dietType: ['Keto', 'Gluten-Free'],
    moodAlignment: '⚡ Energized',
    recipeUrl: '#',
  },
  {
    id: '6',
    name: 'Sushi Roll Platter',
    description: 'Assorted fresh sushi rolls with wasabi and pickled ginger',
    image: 'https://images.unsplash.com/photo-1700324822763-956100f79b0d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXNoaSUyMGphcGFuZXNlJTIwZm9vZHxlbnwxfHx8fDE3NzAyNjExMTB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    calories: 380,
    prepTime: 40,
    dietType: ['Pescatarian', 'Gluten-Free'],
    moodAlignment: '🚀 Adventurous',
    recipeUrl: '#',
  },
];

export function MealSuggestions() {
  const location = useLocation();
  const navigate = useNavigate();
  const [favorites, setFavorites] = useState<string[]>([]);
  const [suggestions, setSuggestions] = useState<Meal[]>([]);
  
  const { mood, diets, weather, temperature } = location.state || {};
  
  useEffect(() => {
    // Load favorites from localStorage
    const savedFavorites = localStorage.getItem('favorites');
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
    
    // Generate initial suggestions
    generateSuggestions();
  }, []);
  
  const generateSuggestions = () => {
    // Filter meals based on dietary preferences
    let filtered = [...mockMeals];
    
    if (diets && diets.length > 0 && !diets.includes('none')) {
      filtered = filtered.filter(meal => 
        diets.some((diet: string) => 
          meal.dietType.some(mealDiet => 
            mealDiet.toLowerCase().includes(diet.toLowerCase())
          )
        )
      );
    }
    
    // Shuffle and select random meals
    const shuffled = filtered.sort(() => Math.random() - 0.5);
    setSuggestions(shuffled.slice(0, 3));
  };
  
  const handleToggleFavorite = (mealId: string) => {
    const newFavorites = favorites.includes(mealId)
      ? favorites.filter(id => id !== mealId)
      : [...favorites, mealId];
    
    setFavorites(newFavorites);
    localStorage.setItem('favorites', JSON.stringify(newFavorites));
  };
  
  if (!mood) {
    navigate('/');
    return null;
  }
  
  return (
    <div className="min-h-screen pt-16 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="mb-12">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Home</span>
          </button>
          
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-4xl mb-2">Your Personalized Meal Suggestions</h1>
              <p className="text-gray-600">
                Based on your mood, dietary preferences, and current weather ({temperature}°F, {weather})
              </p>
            </div>
            
            <button
              onClick={generateSuggestions}
              className="flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-[#FF6B35] to-[#FF6B9D] text-white hover:shadow-lg transition-shadow"
            >
              <RefreshCw className="w-5 h-5" />
              <span>Try Again</span>
            </button>
          </div>
        </div>
        
        {/* Meal Grid */}
        {suggestions.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {suggestions.map((meal, index) => (
              <motion.div
                key={meal.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <MealCard
                  meal={meal}
                  isFavorite={favorites.includes(meal.id)}
                  onToggleFavorite={handleToggleFavorite}
                />
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">🍽️</div>
            <h3 className="text-2xl mb-2">No meals found</h3>
            <p className="text-gray-600 mb-6">
              Try adjusting your dietary preferences or mood selection
            </p>
            <button
              onClick={() => navigate('/')}
              className="px-6 py-3 rounded-full bg-gradient-to-r from-[#FF6B35] to-[#FF6B9D] text-white hover:shadow-lg transition-shadow"
            >
              Go Back
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

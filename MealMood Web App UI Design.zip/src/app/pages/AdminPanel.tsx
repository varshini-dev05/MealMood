import { useState } from 'react';
import { motion } from 'motion/react';
import { Plus, Edit2, Trash2, TrendingUp, Users, Utensils } from 'lucide-react';

interface MealData {
  id: string;
  name: string;
  description: string;
  calories: number;
  prepTime: number;
  dietType: string[];
  moodAlignment: string;
}

export function AdminPanel() {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newMeal, setNewMeal] = useState<Partial<MealData>>({
    name: '',
    description: '',
    calories: 0,
    prepTime: 0,
    dietType: [],
    moodAlignment: '',
  });
  
  // Mock analytics data
  const stats = [
    { label: 'Total Meals', value: '156', icon: Utensils, color: 'from-[#FFD93D] to-[#FF6B35]' },
    { label: 'Active Users', value: '2,847', icon: Users, color: 'from-[#6BCF7F] to-[#4ECDC4]' },
    { label: 'Suggestions Today', value: '1,234', icon: TrendingUp, color: 'from-[#A594F9] to-[#FF6B9D]' },
  ];
  
  const handleAddMeal = () => {
    // In a real app, this would send to a backend
    console.log('Adding meal:', newMeal);
    setShowAddModal(false);
    setNewMeal({
      name: '',
      description: '',
      calories: 0,
      prepTime: 0,
      dietType: [],
      moodAlignment: '',
    });
  };
  
  return (
    <div className="min-h-screen pt-16 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl mb-2">Admin Panel</h1>
          <p className="text-gray-600">Manage meals and view analytics</p>
        </div>
        
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-3xl p-6 shadow-lg border border-gray-100"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className="text-3xl mb-1">{stat.value}</div>
              <div className="text-gray-600">{stat.label}</div>
            </motion.div>
          ))}
        </div>
        
        {/* Add Meal Button */}
        <div className="mb-8">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-[#FF6B35] to-[#FF6B9D] text-white hover:shadow-lg transition-shadow"
          >
            <Plus className="w-5 h-5" />
            <span>Add New Meal</span>
          </button>
        </div>
        
        {/* Meals Table */}
        <div className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-2xl">Meal Database</h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-4 text-left text-sm text-gray-600">Meal Name</th>
                  <th className="px-6 py-4 text-left text-sm text-gray-600">Diet Type</th>
                  <th className="px-6 py-4 text-left text-sm text-gray-600">Mood</th>
                  <th className="px-6 py-4 text-left text-sm text-gray-600">Calories</th>
                  <th className="px-6 py-4 text-left text-sm text-gray-600">Prep Time</th>
                  <th className="px-6 py-4 text-left text-sm text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                <tr className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">Rainbow Buddha Bowl</td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 rounded-full bg-green-100 text-green-700 text-xs">Vegan</span>
                  </td>
                  <td className="px-6 py-4">😊 Happy</td>
                  <td className="px-6 py-4">450</td>
                  <td className="px-6 py-4">25 min</td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                        <Edit2 className="w-4 h-4 text-gray-600" />
                      </button>
                      <button className="p-2 hover:bg-red-50 rounded-lg transition-colors">
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </button>
                    </div>
                  </td>
                </tr>
                <tr className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">Fluffy Blueberry Pancakes</td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 rounded-full bg-blue-100 text-blue-700 text-xs">Vegetarian</span>
                  </td>
                  <td className="px-6 py-4">🤗 Comfort</td>
                  <td className="px-6 py-4">380</td>
                  <td className="px-6 py-4">20 min</td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                        <Edit2 className="w-4 h-4 text-gray-600" />
                      </button>
                      <button className="p-2 hover:bg-red-50 rounded-lg transition-colors">
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </button>
                    </div>
                  </td>
                </tr>
                <tr className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">Grilled Herb Chicken</td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 rounded-full bg-orange-100 text-orange-700 text-xs">Keto</span>
                  </td>
                  <td className="px-6 py-4">⚡ Energized</td>
                  <td className="px-6 py-4">420</td>
                  <td className="px-6 py-4">35 min</td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                        <Edit2 className="w-4 h-4 text-gray-600" />
                      </button>
                      <button className="p-2 hover:bg-red-50 rounded-lg transition-colors">
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      {/* Add Meal Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl"
          >
            <h2 className="text-3xl mb-6">Add New Meal</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm mb-2">Meal Name</label>
                <input
                  type="text"
                  value={newMeal.name}
                  onChange={(e) => setNewMeal({ ...newMeal, name: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#FF6B35]"
                  placeholder="e.g., Rainbow Buddha Bowl"
                />
              </div>
              
              <div>
                <label className="block text-sm mb-2">Description</label>
                <textarea
                  value={newMeal.description}
                  onChange={(e) => setNewMeal({ ...newMeal, description: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#FF6B35] h-24 resize-none"
                  placeholder="Brief description of the meal"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm mb-2">Calories</label>
                  <input
                    type="number"
                    value={newMeal.calories}
                    onChange={(e) => setNewMeal({ ...newMeal, calories: parseInt(e.target.value) })}
                    className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#FF6B35]"
                    placeholder="450"
                  />
                </div>
                
                <div>
                  <label className="block text-sm mb-2">Prep Time (min)</label>
                  <input
                    type="number"
                    value={newMeal.prepTime}
                    onChange={(e) => setNewMeal({ ...newMeal, prepTime: parseInt(e.target.value) })}
                    className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#FF6B35]"
                    placeholder="25"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm mb-2">Mood Alignment</label>
                <select
                  value={newMeal.moodAlignment}
                  onChange={(e) => setNewMeal({ ...newMeal, moodAlignment: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#FF6B35]"
                >
                  <option value="">Select mood</option>
                  <option value="😊 Happy">😊 Happy</option>
                  <option value="⚡ Energized">⚡ Energized</option>
                  <option value="😌 Calm">😌 Calm</option>
                  <option value="🤗 Comfort">🤗 Comfort</option>
                  <option value="🚀 Adventurous">🚀 Adventurous</option>
                  <option value="🌟 Light">🌟 Light</option>
                </select>
              </div>
            </div>
            
            <div className="flex gap-4 mt-8">
              <button
                onClick={handleAddMeal}
                className="flex-1 px-6 py-3 rounded-full bg-gradient-to-r from-[#FF6B35] to-[#FF6B9D] text-white hover:shadow-lg transition-shadow"
              >
                Add Meal
              </button>
              <button
                onClick={() => setShowAddModal(false)}
                className="flex-1 px-6 py-3 rounded-full border-2 border-gray-200 text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
